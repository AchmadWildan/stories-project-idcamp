import Swal from 'sweetalert2/dist/sweetalert2.js'

export default class AboutPage {
  async render() {
    return ``;
  }

  async afterRender() {
    Swal.fire({
      title: "About Page",
      text: "Halaman about akan segera hadir.",
      icon: "info",
    }).then(() => {
      location.href = '#/';
    }
    );
  }
}
